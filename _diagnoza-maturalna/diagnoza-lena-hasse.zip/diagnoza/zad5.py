with open('szachy.txt','r') as plik:
    tekst=plik.readlines()
    lista=[]
    tymczasowa=[]
    for linia in tekst:
        linia.strip()
        if len(tymczasowa)==8:
            lista.append(tymczasowa)
            tymczasowa=[]
            tymczasowa.append(linia.strip())
        if len(tymczasowa)<8:
            tymczasowa.append(linia.strip())
    for szachownica in lista:
        wynik=0
        for wiersz in szachownica:
            for pole in wiersz:
                if pole=='.':
                    wynik+=1
    with open('wyniki5.txt','a+') as wyniki:
        wyniki.write(str(wynik))
        wyniki.write('\n')



