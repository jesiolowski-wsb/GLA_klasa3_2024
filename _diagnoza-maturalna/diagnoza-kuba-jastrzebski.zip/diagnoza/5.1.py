with open('szachy_przyklad.txt', 'r') as file:
    plansze = []
    for i in range(125):
        plansze.append([i.strip() for i in file.readlines(64)])
        file.readline(1)

plansza_counter = 0
max_empty_rows = 0
empty_rows = 0

for plansza in plansze:
    if empty_rows > max_empty_rows: max_empty_rows = empty_rows
    if empty_rows > 0: plansza_counter += 1
    empty_rows = 0
    for i in range(8):
        if set([j[i] for j in plansza]) == ".":
            empty_rows += 1

print(plansza_counter, max_empty_rows)########