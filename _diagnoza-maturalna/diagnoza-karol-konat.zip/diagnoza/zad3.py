def add_leading_zero(str_num):
    if len(str_num) == 1:
        str_num = list(str_num)
        str_num.insert(0, '0')
        str_num = ''.join(str_num)

    return str_num


fp = open("pi.txt", 'r')
lines = fp.readlines()
fp.close()

resoult = ""

# 3.1
res = 0
for i in range(0, len(lines)-1):
    frag = 10*int(lines[i])+int(lines[i+1])
    if frag > 90:
        res += 1

resoult += f"ZADANIE 3.1\n{res}\n\n"

# 3.2
tabl = [0 for i in range(100)]

for i in range(0, len(lines)-1):
    frag = 10*int(lines[i])+int(lines[i+1])
    tabl[frag] += 1

mini = 99999
mini_num = ''
maxi = 00000
maxi_num = ''
for i in range(len(tabl)):
    if tabl[i] < mini:
        mini_num = str(i)
        mini = tabl[i]
    elif tabl[i] > maxi:
        maxi_num = str(i)
        maxi = tabl[i]

mini_num = add_leading_zero(mini_num)
maxi_num = add_leading_zero(maxi_num)

resoult += f"ZADANIE 3.2\n{mini_num} {mini}\n{maxi_num} {maxi}\n\n"


## 3.3
res = 0
for i in range(len(lines)-4):
    switch = False
    for j in range(5):
        if not switch and int(lines[i+j]) > int(lines[i+j+1]):
            switch = True
        if switch and int(lines[i+j]) < int(lines[i+j+1]):
            break
    else:
        res+=1

resoult += f"ZADANIE 3.3\n{res}\n\n"

# 3.4
longst = 0
lindex = 0
ciag = []
for i in range(len(lines)):
    switch = False
    for j in range(len(lines)-i):
        if j+i+1>=len(lines) or (switch  and int(lines[i+j]) < int(lines[i+j+1])):
            if j+1 > longst:
                longst = j+1
                lindex = i+1
                ciag = lines[i:i+j+1]
            break
        if not switch and int(lines[i+j]) > int(lines[i+j+1]):
            switch = True

ciag = [c[0] for c in ciag]

resoult += f"ZADANIE 3.4\n{lindex}\n{''.join(ciag)}\n\n"
fp = open("wyniki3.txt", 'w')
fp.write(resoult)
fp.close()