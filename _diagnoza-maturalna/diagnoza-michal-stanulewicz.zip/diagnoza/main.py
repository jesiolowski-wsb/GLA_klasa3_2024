i=0
a=0
d=0
g=0
b=[]
u=[]
with (open("pi.txt",'r') as niga):
    w=niga.read()
    l=w.split("\n")

    while i<(len(l)-1):
        k=str(l[i])+str(l[i+1])
        k=int(k)

        if k>90:
            a=a+1
        i=i+1
    while True:
        h=str(d)+str(g)
        if h=="100":
            break
        g=g+1
        if g==10:
            g=0
            d=d+1
        b.append(h)
    i=0
    while i<=99:
      u.append(l.count(b[i]))
      i=i+1
      o=max(u)
    print("najwięcej jest elementów :",u.index(o),"i jest ich :",u[o])


print(b)
print(a)
print("najwięcej jest elementów :",u.index(o),"i jest ich :",u[o])
