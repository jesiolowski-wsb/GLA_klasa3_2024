ctr = 0

def nwd(a, b):
    global ctr
    ctr+=1
    print(f"NWD({a}, {b})")
    if b == 0:
        return a
    return nwd(b, a%b)

print(nwd(72, 56), ctr)