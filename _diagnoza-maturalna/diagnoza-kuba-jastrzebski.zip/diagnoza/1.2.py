def find_this_plz(n, w, k):
    n_bin = ""
    for j in [2^i for i in range(n-1, 1, -1)]:
        if j < n:
            n -= j
            n_bin += "1"
        else: n_bin += "0"
        if n == 0: break
    return n_bin[len(n_bin) % (w * k)]

print(find_this_plz(179, 4, 5))#########