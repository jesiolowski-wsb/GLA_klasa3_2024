def func():
    with open('pi.txt', 'r') as file:
        text = [i.strip() for i in file.readlines()]

    counter = 0

    segments = [int(text[i] + text[i+1] + text[i+2] + text[i+3] + text[i+4] + text[i+5]) for i in range(len(text)-5)]
    for segment in segments:
        for i in range(2, (len(str(segment)) - 3)):
            ascending = str(segment)[0:i]
            descending = str(segment)[i:len(str(segment))]
            if ascending == sorted(ascending) and descending == sorted(ascending, reverse=True):
                counter += 1
                break

    print(counter)


func()######