lista=['*']*3*2
print(lista)