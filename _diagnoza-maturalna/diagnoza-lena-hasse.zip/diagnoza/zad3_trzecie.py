with open('pi_przyklad.txt','r') as plik:
    tekst = plik.readlines()
    lista_pi = [i.strip() for i in tekst]
    for i in range(len(lista_pi)):
        lista_po_6 = []
        for j in range(i,6):
            lista_po_6.append(j)
            print(lista_po_6)
        if len(lista_po_6)==6:
            for x in lista_po_6:
                posortowana_po_6 = [lista_po_6.sort()]
                if lista_po_6[1]==max(lista_po_6):
                    break

