#print([2**i for i in range(178**(1/2), 1, -1)])
print([i for i in range(178, 1, -1)])

if [True, False, True]:
    print("a")