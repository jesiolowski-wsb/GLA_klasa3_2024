with open('szachy.txt','r') as plik:
    tekst=plik.readlines()
    lista=[]
    tymczasowa=[]
    for linia in tekst:
        linia.strip()
        if len(tymczasowa)==8:
            lista.append(tymczasowa)
            tymczasowa=[]
            tymczasowa.append(linia.strip())
        if len(tymczasowa)<8:
            tymczasowa.append(linia.strip())
    liczba_plansz=0
    najmniej_bierek=0
    for szachownica in lista:
        biale=0
        czarne=0
        for wiersz in szachownica:
            for pole in wiersz:
                if pole.islower:
                    czarne+=1
                if pole.isupper():
                    biale+=1
        if biale==czarne:
            liczba_plansz+=1
            if najmniej_bierek>biale:
                najmniej_bierek=biale

with open('wyniki5.txt','a+') as wyniki:
    wyniki.write(f'liczba plansz:{liczba_plansz}')
    wyniki.write('\n')
    wyniki.write(f'najmniej bierek: {najmniej_bierek}')


