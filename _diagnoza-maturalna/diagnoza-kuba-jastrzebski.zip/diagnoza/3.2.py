def func():
    with open('pi.txt', 'r') as file:
        text = [i.strip() for i in file.readlines()]

    segments = [text[i] + text[i+1] for i in range(len(text)-1)]

    min_num = 0
    min_count = 9999
    max_num = 0
    max_count = 0
    for j in ['0'+str(i) for i in range(10)]+[str(i) for i in range(10, 100)]:
        if segments.count(j) > max_count:
            max_count = segments.count(j)
            max_num = j
        if segments.count(j) < min_count:
            min_count = segments.count(j)
            min_num = j

    print(min_num, min_count, "\n", max_num, max_count)


func()


