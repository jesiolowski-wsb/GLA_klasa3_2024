with open('pi.txt','r') as plik:
    tekst = plik.readlines()
    lista_pi = [i.strip() for i in tekst]
    baza_danych={}
    for x in range(10):
        for y in range(10):
            fragment=str(x)+str(y)
            baza_danych[fragment]=0


    for i in range(len(lista_pi) - 1):
        zmienna = lista_pi[i] + lista_pi[i + 1]
        baza_danych[zmienna]+=1


    najwieksza=max(baza_danych.values())
    najmniejsza=min(baza_danych.values())
    with open('wyniki3.txt','a+') as wyniki:
        wyniki.write(str(najwieksza))
        wyniki.write('\n')
        wyniki.write(str(najmniejsza))