with open('szachy.txt', 'r') as file:
    plansze = []
    for i in range(125):
        plansze.append([i.strip() for i in file.readlines(64)])
        file.readline(1)

    plansza_count = 0
    min_bierki_number = 999

for plansza in plansze:
    figury_lower = []
    figury_upper = []
    for line in plansza:
        for letter in line:
            if letter.isalpha():
                if letter.islower(): figury_lower.append(letter)
                else: figury_upper.append(letter)
    figury_lower = sorted(figury_lower)
    figury_upper = sorted(i.lower() for i in figury_upper)

    if len(figury_upper) == 0 or len(figury_lower) == 0: continue

    if figury_upper == figury_lower:
        plansza_count += 1
        if 2 * len(figury_lower) < min_bierki_number: min_bierki_number = 2 * len(figury_lower)

print(plansza_count)
print(min_bierki_number)
