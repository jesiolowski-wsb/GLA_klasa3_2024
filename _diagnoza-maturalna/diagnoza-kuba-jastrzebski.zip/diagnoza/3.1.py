def func():
    with open('pi.txt', 'r') as file:
        text = [i.strip() for i in file.readlines()]

    segments = [int(text[i] + text[i+1]) for i in range(len(text)-1) if int(text[i] + text[i+1]) > 90]
    return len(segments)


print(func())

