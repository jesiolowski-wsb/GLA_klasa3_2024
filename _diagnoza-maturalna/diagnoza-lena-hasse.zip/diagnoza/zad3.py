with open('pi.txt','r') as plik:
    tekst = plik.readlines()
    lista_pi = [i.strip() for i in tekst]
    def wieksze_od_90(lista):
        wynik=0

        for i in range(len(lista)-1):
            zmienna=int(lista[i]+lista[i+1])
            if zmienna>90:
                wynik+=1
        return wynik

with open('wyniki3.txt','a+') as wyniki:
    wyniki.write(str(wieksze_od_90(lista_pi)))
    wyniki.write('\n')
