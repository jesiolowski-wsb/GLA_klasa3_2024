from zad3 import resoult, lines

fp = open('szachy.txt', 'r')
board = fp.readlines()
fp.close()

boards = []
tmp = []
for line in board:
    if line == '\n':
        boards.append(tmp)
        tmp = []
        continue
    tmp.append(line[:-1])

boards.append(tmp)

resoult = ''

## 5.1
empty_countr = 0
max_empty = 0
for board in boards:
    empty_cols = 8
    for col in range(8):
        for row in range(8):
            if not board[row][col] == '.':
                empty_cols-=1
                break
    if empty_cols > 0:
        empty_countr+=1

    max_empty = max(max_empty, empty_cols)

resoult += f"ZADANIE 5.1\n{empty_countr} {max_empty}\n\n"

# 5.2
whites = {}
blacks = {}

def reset_dicts():
    global whites
    global blacks
    whites = {
        'k': 0,
        'w': 0,
        's': 0,
        'h': 0,
        'g': 0,
        'p': 0,
    }

    blacks = {
        'k': 0,
        'w': 0,
        's': 0,
        'h': 0,
        'g': 0,
        'p': 0,
    }

equals = 0
equals_min = 99999999
for board in boards:
    reset_dicts()
    for row in range(8):
        for col in range(8):
            if board[row][col] == '.':
                continue
            c = board[row][col]
            if c.isupper():
                c = c.lower()
                whites[c] += 1
            else:
                blacks[c] += 1
    numynumy = 0
    for key in whites:
        if not whites[key] == blacks[key]:
            break
        numynumy += whites[key]
    else:
        equals_min = min(equals_min, numynumy)
        equals += 1

resoult += f"ZADANIE 5.2\n{equals} {equals_min*2}\n\n"

## ZAD 5.3
def check_szach(x, y, bd, k):
    for i in range(x+1, 8):
        if bd[y][i] == k:
            return True
        if not bd[y][i] == '.':
            break

    for i in range(x-1, -1, -1):
        if bd[y][i] == k:
            return True
        if not bd[y][i] == '.':
            break

    for i in range(y+1, 8):
        if bd[i][x] == k:
            return True
        if not bd[i][x] == '.':
            break

    for i in range(y-1, -1, -1):
        if bd[y][i] == k:
            return True
        if not bd[i][x] == '.':
            break

    return False

white_check = 0
black_check = 0
for board in boards:
    for row in range(8):
        for col in range(8):
            if board[row][col] == 'W' and check_szach(col, row, board, 'k'):
                white_check+=1
                break
            if board[row][col] == 'w' and check_szach(col, row, board, 'K'):
                black_check+=1
                break

resoult += f"ZADANIE 5.3\n{white_check} {black_check}"

fp = open("wyniki5.txt", 'w')
fp.write(resoult)
fp.close()
print(resoult)