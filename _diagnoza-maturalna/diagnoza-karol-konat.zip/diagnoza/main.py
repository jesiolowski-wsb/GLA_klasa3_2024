

def tobin(n):
    num = ''
    lenbin = 0
    while n > 0:
        lenbin+=1
        num += str(n%2)
        n = n//2
    return num[::-1], lenbin+2

w = 4
k = 5

n = 179
n_org = n
n, lenbin = tobin(n)
a = w*k//(lenbin-2)
b = w*k-(lenbin-2)*a
print(bin(n_org))
g = n_org % 2**b
print(g)