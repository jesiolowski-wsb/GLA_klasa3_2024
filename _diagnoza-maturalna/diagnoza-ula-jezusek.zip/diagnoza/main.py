3.1
with open('pi.txt', 'r') as plik:
    tekst = plik.readlines()
    a = []
    for i in tekst:
        a.append(i)
def fragmenty(a):
    b = []
    licznik = 0
    for i in a:
        i = 10*i + a[i+1]
        b.append(i)
    for i in b:
        if i > 90:
            licznik += 1
    return licznik
print(fragmenty(tekst))


